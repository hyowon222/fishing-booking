import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import {
  CreateFishingSourceBody,
  DeleteFishingSourceParams,
  GetFishingFilterOptionsResponse,
  SearchFishingSchedulesQueryParams,
  SearchFishingSchedulesResponse,
  UpdateFishingSourceBody,
  UpdateFishingSourceParams,
} from "@workspace/api-zod";
import { db, fishingSourcesTable } from "@workspace/db";
import {
  clearSourceCache,
  getFilterOptions,
  getSchedules,
  getSourceLabel,
  listConfiguredSources,
} from "../lib/fishing-source";

const router: IRouter = Router();

function queryValues(value: unknown): string[] | undefined {
  if (value === undefined) return undefined;
  if (Array.isArray(value)) return value.map(String).filter(Boolean);
  return [String(value)].filter(Boolean);
}

function dateValue(value: unknown): Date {
  return new Date(`${String(value)}T00:00:00.000Z`);
}

router.get("/fishing/schedules", async (req, res) => {
  const parsed = SearchFishingSchedulesQueryParams.safeParse({
    startDate: dateValue(req.query.startDate),
    endDate: dateValue(req.query.endDate),
    region: queryValues(req.query.region),
    port: req.query.port ? String(req.query.port) : undefined,
    ship: queryValues(req.query.ship),
    tide: req.query.tide ? String(req.query.tide) : undefined,
  });

  if (!parsed.success) {
    res.status(400).json({ error: "시작일과 종료일을 올바른 날짜로 입력해 주세요." });
    return;
  }

  const startDate = parsed.data.startDate.toISOString().slice(0, 10);
  const endDate = parsed.data.endDate.toISOString().slice(0, 10);
  const rangeDays = Math.round(
    (parsed.data.endDate.getTime() - parsed.data.startDate.getTime()) / 86_400_000,
  );
  if (parsed.data.endDate < parsed.data.startDate || rangeDays > 90) {
    res.status(400).json({ error: "검색 범위는 최대 90일이며 종료일은 시작일 이후여야 합니다." });
    return;
  }

  try {
    const search = await getSchedules(startDate, endDate);
    const region = parsed.data.region || [];
    const ship = parsed.data.ship || [];
    const items = search.items.filter((item) => {
      const departureMatches = item.departureDate >= startDate && item.departureDate <= endDate;
      const regionMatches = region.length === 0 || region.includes(item.region);
      const portMatches = !parsed.data.port || parsed.data.port === item.port;
      const shipMatches = ship.length === 0 || ship.includes(item.vessel);
      const tideMatches = !parsed.data.tide || parsed.data.tide === item.tide;
      return departureMatches && regionMatches && portMatches && shipMatches && tideMatches;
    });
    const response = SearchFishingSchedulesResponse.parse({
      items,
      total: items.length,
      searchedAt: new Date(),
      source: getSourceLabel(search.sources),
      cachedUntil: new Date(Date.now() + 5 * 60 * 1000),
      warning: search.failedSources.length
        ? `일부 예약처를 불러오지 못했습니다: ${search.failedSources.join(", ")}`
        : null,
    });
    res.json(response);
  } catch (error) {
    req.log.error({ err: error }, "Fishing source lookup failed");
    res.status(502).json({ error: "예약 원본을 불러오지 못했습니다. 잠시 후 다시 시도해 주세요." });
  }
});

router.get("/fishing/options", async (_req, res) => {
  try {
    const today = new Date();
    const end = new Date(today);
    end.setUTCDate(end.getUTCDate() + 90);
    const startDate = today.toISOString().slice(0, 10);
    const endDate = end.toISOString().slice(0, 10);
    const options = GetFishingFilterOptionsResponse.parse(
      getFilterOptions((await getSchedules(startDate, endDate)).items),
    );
    res.json(options);
  } catch (error) {
    res.status(502).json({ error: "필터 목록을 불러오지 못했습니다. 잠시 후 다시 시도해 주세요." });
  }
});

router.get("/fishing/sources", async (_req, res) => {
  try {
    res.json(await listConfiguredSources());
  } catch (error) {
    res.status(500).json({ error: "예약처 목록을 불러오지 못했습니다." });
  }
});

router.post("/fishing/sources", async (req, res) => {
  const parsed = CreateFishingSourceBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "이름, 지역, 항구, 예약처 URL을 모두 올바르게 입력해 주세요." });
    return;
  }

  try {
    const [source] = await db
      .insert(fishingSourcesTable)
      .values({ ...parsed.data, enabled: parsed.data.enabled ?? true })
      .returning();
    clearSourceCache();
    res.status(201).json(source);
  } catch (error: unknown) {
    if (error && typeof error === "object" && "code" in error && error.code === "23505") {
      res.status(409).json({ error: "이미 등록된 예약처 URL입니다." });
      return;
    }
    req.log.error({ err: error }, "Fishing source creation failed");
    res.status(500).json({ error: "예약처를 추가하지 못했습니다." });
  }
});

router.patch("/fishing/sources/:id", async (req, res) => {
  const params = UpdateFishingSourceParams.safeParse({ id: Number(req.params.id) });
  const parsed = UpdateFishingSourceBody.safeParse(req.body);
  if (!params.success || !parsed.success) {
    res.status(400).json({ error: "이름, 지역, 항구, 예약처 URL을 모두 올바르게 입력해 주세요." });
    return;
  }

  try {
    const [source] = await db
      .update(fishingSourcesTable)
      .set({ ...parsed.data, enabled: parsed.data.enabled ?? true, updatedAt: new Date() })
      .where(eq(fishingSourcesTable.id, params.data.id))
      .returning();
    if (!source) {
      res.status(404).json({ error: "예약처를 찾을 수 없습니다." });
      return;
    }
    clearSourceCache();
    res.json(source);
  } catch (error: unknown) {
    if (error && typeof error === "object" && "code" in error && error.code === "23505") {
      res.status(409).json({ error: "이미 등록된 예약처 URL입니다." });
      return;
    }
    req.log.error({ err: error }, "Fishing source update failed");
    res.status(500).json({ error: "예약처를 수정하지 못했습니다." });
  }
});

router.delete("/fishing/sources/:id", async (req, res) => {
  const params = DeleteFishingSourceParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) {
    res.status(400).json({ error: "예약처 ID가 올바르지 않습니다." });
    return;
  }

  const [source] = await db
    .delete(fishingSourcesTable)
    .where(eq(fishingSourcesTable.id, params.data.id))
    .returning({ id: fishingSourcesTable.id });
  if (!source) {
    res.status(404).json({ error: "예약처를 찾을 수 없습니다." });
    return;
  }
  clearSourceCache();
  res.status(204).send();
});

export default router;